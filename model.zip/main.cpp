#include "controller.h"

int main(int argc, char** argv) {
    Controller c;
    c.loop();
    return 0;
}
